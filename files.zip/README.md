# Stellar Charity Vault

A full-stack project for the Stellar Bootcamp at IIIT NR.  
Create and contribute to transparent charity vaults on Stellar using Soroban smart contracts.

## Features
- Create charity vaults with funding goals and deadlines.
- Contribute XLM to vaults.
- Funds are released only if the goal is met.
- Refunds enabled if the goal isn’t reached.

## Tech Stack
- Soroban smart contract (Rust)
- React.js frontend

## Setup

### Soroban Contract
1. Install [Rust](https://www.rust-lang.org/tools/install)
2. Install Soroban CLI:  
   cargo install --locked --version 20.0.0-rc.2 soroban-cli
3. Build contract:
   ```
   cd soroban-contract
   cargo build --target wasm32-unknown-unknown --release
   ```

### Frontend
1. Install Node.js (v18+)
2. In `/frontend`:
   ```
   npm install
   npm start
   ```
3. Configure Stellar/Soroban endpoints in `src/App.js` as needed.

## Deploying Smart Contract

- Use Soroban CLI to deploy the compiled `.wasm` to Stellar testnet.
- Example:
  ```
  soroban contract deploy --wasm target/wasm32-unknown-unknown/release/soroban_charity_vault.wasm --network testnet
  ```

## VS Code
- Open folder in VS Code: `code .`
- Install recommended extensions for Rust and JS.

---