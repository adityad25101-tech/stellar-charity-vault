#![no_std]

use soroban_sdk::{contractimpl, symbol, Address, Env, Symbol, Map, Uint128};

pub struct CharityVault;

#[derive(Clone)]
pub struct Vault {
    pub goal: Uint128,
    pub raised: Uint128,
    pub deadline: u64,
    pub beneficiary: Address,
    pub contributors: Map<Address, Uint128>,
    pub claimed: bool,
}

#[contractimpl]
impl CharityVault {
    pub fn create_vault(
        env: Env,
        id: Symbol,
        goal: Uint128,
        deadline: u64,
        beneficiary: Address,
    ) {
        let vault = Vault {
            goal,
            raised: 0u128.into(),
            deadline,
            beneficiary,
            contributors: Map::new(&env),
            claimed: false,
        };
        env.storage().set(&id, &vault);
    }

    pub fn contribute(env: Env, id: Symbol, from: Address, amount: Uint128) {
        let mut vault: Vault = env.storage().get_unchecked(&id).unwrap();
        vault.raised += amount;
        let old = vault.contributors.get(from.clone()).unwrap_or(0u128.into());
        vault.contributors.set(from, old + amount);
        env.storage().set(&id, &vault);
    }

    pub fn claim(env: Env, id: Symbol, now: u64) {
        let mut vault: Vault = env.storage().get_unchecked(&id).unwrap();
        assert!(!vault.claimed, "Already claimed");
        assert!(vault.raised >= vault.goal, "Goal not met");
        assert!(now >= vault.deadline, "Deadline not reached");
        // Here you would transfer funds to beneficiary
        vault.claimed = true;
        env.storage().set(&id, &vault);
    }

    pub fn refund(env: Env, id: Symbol, from: Address, now: u64) {
        let mut vault: Vault = env.storage().get_unchecked(&id).unwrap();
        assert!(now >= vault.deadline, "Deadline not reached");
        assert!(vault.raised < vault.goal, "Goal met, no refunds");
        let amount = vault.contributors.get(from.clone()).unwrap_or(0u128.into());
        // Here you would transfer back to contributor
        vault.contributors.set(from, 0u128.into());
        env.storage().set(&id, &vault);
    }
}