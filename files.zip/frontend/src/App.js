import React, { useState } from "react";
import { Keypair, Server } from "stellar-sdk";

const server = new Server("https://horizon-testnet.stellar.org");

export default function App() {
  const [keypair, setKeypair] = useState(null);
  const [balance, setBalance] = useState(null);

  // Generate wallet
  const createWallet = async () => {
    const kp = Keypair.random();
    setKeypair(kp);
    // Fund using friendbot
    await fetch(`https://friendbot.stellar.org?addr=${kp.publicKey()}`);
    // Fetch balance
    const account = await server.loadAccount(kp.publicKey());
    setBalance(account.balances[0].balance);
  };

  return (
    <div style={{ padding: 30 }}>
      <h1>Stellar Charity Vault</h1>
      <button onClick={createWallet}>Create Demo Wallet</button>
      {keypair && (
        <div>
          <p><b>Public Key:</b> {keypair.publicKey()}</p>
          <p><b>Secret:</b> {keypair.secret()}</p>
          <p><b>Balance:</b> {balance} XLM</p>
        </div>
      )}
      <p>Smart contract vault interaction coming soon!</p>
    </div>
  );
}